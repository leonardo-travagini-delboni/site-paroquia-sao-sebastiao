<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <!-- About the Church Start -->
    <div class="container-fluid bg-light overflow-hidden my-5 px-lg-0">
        <div class="container feature px-lg-0">
            <div class="row g-0 mx-lg-0">
                <div class="col-lg-6 feature-text py-5 wow fadeIn" data-wow-delay="0.5s">
                    <div class="p-lg-5 ps-lg-0">
                        <div class="section-title text-start">
                            <h1 class="display-5 mb-4">SEJA UM DOADOR</h1>
                        </div>
                        <p class="mb-4 pb-2">
                            Vamos juntos pescar almas! Contribua com qualquer valor!<br><br>Recebedor: <strong>PAROQUIA DE SAO SEBASTIAO</strong><br>Chave PIX: <strong>03.707.358/0033-24 (CNPJ)</strong><br>Banco: <strong>CAIXA ECONOMICA FEDERAL</strong><br>
                            <hr>
                            <strong>ATENÇÃO! Cheque os dados do recebedor antes de enviar o PIX! </strong>
                            <br>
                            <span style="color: red;">Websites estão sujeitos a hackers. <br>Confira os dados do recebedor antes de confirmar o envio!<br>Em caso de dúvida entre em contato direto conosco!</span>
                        </p>
                    </div>
                </div>
                <div class="col-lg-6 pe-lg-0" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="position-absolute img-fluid w-90 h-100" src="img/qr_code_paroquia.png" style="object-fit: cover;" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About the Church End -->    

</body>
</html>


<?php

?>