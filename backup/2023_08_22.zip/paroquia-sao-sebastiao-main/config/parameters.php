<?php
    // Database connections settings:
    $db_server = "127.0.0.1:3306";
    $db_user = "u826974739_paroquia";
    $db_pass = "tgzik}%@h.=6XdZJ7Z";
    $db_name= "u826974739_saosebastiao";

    // Global repo parameters:
    $contact_receiver = "contato@saosebastiaoparoquia.com.br";
?>